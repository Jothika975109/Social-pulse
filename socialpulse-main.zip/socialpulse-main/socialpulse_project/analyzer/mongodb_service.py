import json, os
from datetime import datetime

class MongoDBService:
    def __init__(self):
        self.client=None; self.db=None; self.available=False
        self._connect()
    def _connect(self):
        try:
            from pymongo import MongoClient
            from django.conf import settings
            cfg=getattr(settings,'MONGODB_SETTINGS',{})
            self.client=MongoClient(cfg.get('HOST','localhost'),cfg.get('PORT',27017),serverSelectionTimeoutMS=2000)
            self.client.server_info()
            self.db=self.client[cfg.get('DB','socialpulse')]
            self.available=True
        except: self.available=False
    def save_comments(self,report_id,sentiment):
        return self._save('comments',report_id,{'report_id':str(report_id),'timestamp':datetime.utcnow(),'total':sentiment.get('total',0),'positive':sentiment.get('positive',0),'negative':sentiment.get('negative',0),'spam':sentiment.get('spam',0),'all_positive':sentiment.get('all_positive',[])[:50],'all_negative':sentiment.get('all_negative',[])[:50]})
    def save_fraud_log(self,report_id,fraud):
        return self._save('fraud_logs',report_id,{'report_id':str(report_id),'timestamp':datetime.utcnow(),'fraud_score':fraud.get('fraud_score',0),'risk_level':fraud.get('risk_level','Low'),'alerts':fraud.get('alerts',[])})
    def save_raw_analytics(self,report_id,raw):
        return self._save('raw_analytics',report_id,{'report_id':str(report_id),'timestamp':datetime.utcnow(),'raw':raw})
    def _save(self,col,report_id,doc):
        if self.available:
            try: return str(self.db[col].insert_one(doc).inserted_id)
            except: pass
        try:
            d='/tmp/socialpulse_mongo'; os.makedirs(d,exist_ok=True)
            with open(f'{d}/{col}_{report_id}.json','w') as f: json.dump(doc,f,default=str,indent=2)
        except: pass
        return f'file_{report_id}'
    def get_status(self):
        return {'available':self.available,'type':'MongoDB' if self.available else 'File fallback'}

mongo_service = MongoDBService()
