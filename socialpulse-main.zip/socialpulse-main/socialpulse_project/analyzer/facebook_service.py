
import re, json, random
from django.conf import settings

def parse_facebook_url(url):
    url=url.strip()
    m=re.search(r"(?:photo/\?fbid=|posts/)(\d+)",url)
    if m: return {"type":"post","id":m.group(1)}
    m=re.search(r"facebook\.com/([a-zA-Z0-9.]+)/?$",url)
    if m and m.group(1) not in ["photo","posts","watch","groups","marketplace"]: return {"type":"page","id":m.group(1)}
    return None

def fetch_facebook_data(url):
    parsed=parse_facebook_url(url)
    if not parsed: raise ValueError("Invalid Facebook URL")
    return _mock(parsed,url)

PAGES={"NASA":{"name":"NASA","followers":21000000,"likes":20000000,"posts_week":28,"avg_reactions":45000,"avg_comments":3200,"avg_shares":12000,"country":"US","category":"Science","age":14,"verified":True},"natgeo":{"name":"National Geographic","followers":47000000,"likes":46000000,"posts_week":35,"avg_reactions":85000,"avg_comments":5400,"avg_shares":28000,"country":"US","category":"Media","age":16,"verified":True},"fcbarcelona":{"name":"FC Barcelona","followers":89000000,"likes":88000000,"posts_week":42,"avg_reactions":210000,"avg_comments":18000,"avg_shares":45000,"country":"ES","category":"Sports","age":15,"verified":True},"realmadrid":{"name":"Real Madrid CF","followers":115000000,"likes":114000000,"posts_week":40,"avg_reactions":180000,"avg_comments":14000,"avg_shares":38000,"country":"ES","category":"Sports","age":15,"verified":True}}
POSTS={"123456789":{"content":"Check out our latest update!","page":"NASA","reactions":62000,"comments":4100,"shares":18000,"days_ago":2}}
POS=[{"text":"This is exactly the content we need. Sharing this!","author":"Maria Santos"},{"text":"Absolutely fantastic! Liked and shared with friends ","author":"John Williams"},{"text":"Thank you for always bringing quality content!","author":"Rebecca Thompson"},{"text":"This made my day! Such an inspiring post.","author":"Carlos Mendez"},{"text":"Always reliable and informative. Never disappoints! ","author":"Priya Sharma"},{"text":"Keep up the amazing work! This community appreciates you ","author":"Ahmed Hassan"}]
NEG=[{"text":"The information here seems outdated and misleading.","author":"FactChecker2024"},{"text":"I have seen better quality from smaller pages honestly.","author":"HonestOpinion_FB"},{"text":"Too much promotional content lately. Lost original spirit.","author":"LongTimeFollower"},{"text":"This is getting repetitive. Where is original content?","author":"ContentCritic99"}]
SPAM=[{"text":"CLICK HERE to win a FREE iPhone!! Limited time!!","author":"FakeGiveaway_Bot"},{"text":"Like my page and I will like yours back!","author":"LikeExchange_Bot"},{"text":"Visit my page for amazing deals!!","author":"PromoSpam_2024"},{"text":"Share this to 10 friends and win $1000!!","author":"ChainSpam_Bot"}]

def _mock(parsed,url,error=None):
    rng=random.Random(sum(ord(c) for c in parsed["id"]))
    if parsed["type"]=="post":
        p=POSTS.get(parsed["id"])
        reactions=p["reactions"] if p else rng.randint(1000,80000)
        comments=p["comments"] if p else int(reactions*rng.uniform(0.05,0.15))
        shares=p["shares"] if p else int(reactions*rng.uniform(0.1,0.4))
        posC=rng.randint(3,5); negC=rng.randint(1,3); spamC=rng.randint(1,4)
        pool=([{"text":c["text"],"author":c["author"],"sentiment":"positive","likes":rng.randint(5,200)} for c in POS[:posC]]+[{"text":c["text"],"author":c["author"],"sentiment":"negative","likes":rng.randint(0,30)} for c in NEG[:negC]]+[{"text":c["text"],"author":c["author"],"sentiment":"spam","likes":0} for c in SPAM[:spamC]])
        return {"platform":"facebook","type":"post","id":parsed["id"],"channel_name":p["page"] if p else "Facebook Page","content":p["content"] if p else "Facebook Post","reactions_count":reactions,"comments_count":comments,"shares_count":shares,"published_days_ago":p["days_ago"] if p else rng.randint(1,30),"comments":pool,"source":"demo","demo_note":error or ""}
    else:
        k=next((k for k in PAGES if k.lower() in parsed["id"].lower() or parsed["id"].lower() in k.lower()),None)
        p=PAGES.get(k)
        followers=p["followers"] if p else rng.randint(10000,5000000)
        posC=rng.randint(3,5); negC=rng.randint(1,3); spamC=rng.randint(1,4)
        pool=([{"text":c["text"],"author":c["author"],"sentiment":"positive","likes":rng.randint(5,200)} for c in POS[:posC]]+[{"text":c["text"],"author":c["author"],"sentiment":"negative","likes":rng.randint(0,30)} for c in NEG[:negC]]+[{"text":c["text"],"author":c["author"],"sentiment":"spam","likes":0} for c in SPAM[:spamC]])
        return {"platform":"facebook","type":"page","id":parsed["id"],"channel_name":p["name"] if p else f"Facebook: {parsed['id']}","handle":parsed["id"],"followers_count":followers,"page_likes":p["likes"] if p else int(followers*0.97),"avg_reactions":p["avg_reactions"] if p else int(followers*rng.uniform(0.001,0.01)),"avg_comments":p["avg_comments"] if p else int(followers*0.0003),"avg_shares":p["avg_shares"] if p else int(followers*rng.uniform(0.0005,0.005)),"posts_per_week":p["posts_week"] if p else rng.randint(5,30),"category":p["category"] if p else "General","age":p["age"] if p else rng.randint(1,10),"verified":p["verified"] if p else False,"country":p["country"] if p else "US","comments":pool,"source":"demo","demo_note":error or ""}
