"""
SocialPulse Views — All 3 Platforms: YouTube, Instagram, Facebook
"""
import json
from django.shortcuts import render, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone

from .models import SocialProfile, SocialPost, AnalyticsReport, FraudAlert
from .youtube_service   import parse_youtube_url,   fetch_youtube_data
from .instagram_service import parse_instagram_url, fetch_instagram_data
from .facebook_service  import parse_facebook_url,  fetch_facebook_data
from .analytics_engine  import analyze_comments, detect_fraud, calculate_scores, generate_growth_trend
from .mongodb_service   import mongo_service


def index(request):
    recent = AnalyticsReport.objects.select_related('profile','post').order_by('-created_at')[:6]
    return render(request, 'analyzer/index.html', {'recent_reports': recent, 'mongo_status': mongo_service.get_status()})


@csrf_exempt
@require_http_methods(["POST"])
def analyze(request):
    try:
        body     = json.loads(request.body)
        url      = body.get('url','').strip()
        platform = body.get('platform','youtube').lower()
        if not url:
            return JsonResponse({'error':'Please provide a URL'}, status=400)
        if platform not in ('youtube','instagram','facebook'):
            return JsonResponse({'error':'Invalid platform'}, status=400)

        if platform=='youtube':
            parsed=parse_youtube_url(url)
            if not parsed: return JsonResponse({'error':'Invalid YouTube URL. Use youtube.com/watch?v=... or youtube.com/@channel'}, status=400)
            data=fetch_youtube_data(url)
        elif platform=='instagram':
            parsed=parse_instagram_url(url)
            if not parsed: return JsonResponse({'error':'Invalid Instagram URL. Use instagram.com/username/ or instagram.com/p/postid/'}, status=400)
            data=fetch_instagram_data(url)
        else:
            parsed=parse_facebook_url(url)
            if not parsed: return JsonResponse({'error':'Invalid Facebook URL. Use facebook.com/pagename/ or facebook.com/photo/?fbid=123'}, status=400)
            data=fetch_facebook_data(url)

        comments  = data.get('comments',[])
        sentiment = analyze_comments(comments)
        fraud     = detect_fraud(data, sentiment)
        scores    = calculate_scores(data, sentiment, fraud)
        trend     = generate_growth_trend(data)
        report    = _save_to_sql(data, scores, sentiment, fraud, url, platform)
        mid       = mongo_service.save_comments(report.id, sentiment)
        mongo_service.save_fraud_log(report.id, fraud)
        mongo_service.save_raw_analytics(report.id, {k:v for k,v in data.items() if k!='comments'})
        if mid: report.mongo_report_id=mid; report.save()
        return JsonResponse({'success':True,'data':_build_response(data,scores,sentiment,fraud,trend,report,platform)})

    except ValueError as e:
        return JsonResponse({'error':str(e)}, status=400)
    except Exception as e:
        return JsonResponse({'error':f'Analysis failed: {str(e)}'}, status=500)


def report_detail(request, report_id):
    report = get_object_or_404(AnalyticsReport, id=report_id)
    return render(request, 'analyzer/report.html', {'report': report})


def history(request):
    reports = AnalyticsReport.objects.select_related('profile','post').order_by('-created_at')[:30]
    return render(request, 'analyzer/history.html', {'reports': reports})


def _save_to_sql(data, scores, sentiment, fraud, url, platform):
    ctype=data.get('type','video')
    profile_obj=None; post_obj=None
    if ctype in ('channel','profile','page'):
        profile_obj,_=SocialProfile.objects.update_or_create(
            platform=platform, profile_id=data.get('id',data.get('channel_id','')),
            defaults={'profile_name':data.get('channel_name','Unknown'),'handle':data.get('handle',''),
                'profile_url':url,'followers_count':data.get('subscriber_count') or data.get('followers_count',0),
                'following_count':data.get('following_count',0),
                'total_posts':data.get('video_count') or data.get('posts_count',0),
                'total_views':data.get('total_views',0),'country':data.get('country',''),
                'verified':data.get('verified',False),'category':data.get('category',data.get('niche',''))})
    else:
        post_obj,_=SocialPost.objects.update_or_create(
            platform=platform, post_id=data.get('id',''),
            defaults={'profile':profile_obj,'title':(data.get('title') or data.get('caption') or data.get('content',''))[:200],
                'post_url':url,'view_count':data.get('view_count',0),
                'like_count':data.get('like_count') or data.get('likes_count',0),
                'comment_count':data.get('comment_count') or data.get('comments_count',0),
                'share_count':data.get('shares_count',0),'save_count':data.get('saves_count',0),
                'reaction_count':data.get('reactions_count',0)})
    s=scores['overall_score']
    grade='excellent' if s>=85 else 'good' if s>=70 else 'average' if s>=55 else 'poor' if s>=40 else 'critical'
    ct_map={('youtube','video'):'video',('youtube','channel'):'channel',('instagram','post'):'post',
            ('instagram','profile'):'profile',('facebook','post'):'fb_post',('facebook','page'):'page'}
    ct=ct_map.get((platform,ctype),'video')
    report=AnalyticsReport.objects.create(
        platform=platform,content_type=ct,profile=profile_obj,post=post_obj,analyzed_url=url,
        overall_score=s,performance_grade=grade,engagement_score=scores['engagement_score'],
        reach_score=scores['reach_score'],health_score=scores['health_score'],
        fraud_risk_score=fraud['fraud_score'],engagement_rate=scores['engagement_rate'],
        positive_sentiment=sentiment.get('positive_pct',0),negative_sentiment=sentiment.get('negative_pct',0),
        neutral_sentiment=sentiment.get('neutral_pct',0),spam_detected=sentiment.get('spam',0),
        bot_detected=fraud.get('bot_activity_detected',False),fake_engagement=fraud.get('fake_engagement_detected',False),
        view_spike=fraud.get('view_spike_detected',False))
    for a in fraud.get('alerts',[]):
        FraudAlert.objects.create(report=report,alert_type=a.get('type','spam_comments'),
            severity=a.get('severity','low'),description=a.get('description',''),evidence=a.get('evidence',''))
    return report


def _build_response(data, scores, sentiment, fraud, trend, report, platform):
    return {
        'report_id':report.id,'platform':platform,'content_type':data.get('type','video'),
        'data_source':data.get('source','demo'),'demo_note':data.get('demo_note',''),
        'channel_name':data.get('channel_name',''),'handle':data.get('handle',''),
        'title':data.get('title') or data.get('caption') or data.get('content',''),
        'thumbnail':data.get('thumbnail',''),'verified':data.get('verified',False),
        'country':data.get('country',''),'niche':data.get('niche',data.get('category','')),
        'age':data.get('channel_age_years',data.get('age',0)),
        # YouTube
        'view_count':data.get('view_count',0),'like_count':data.get('like_count',0),
        'comment_count':data.get('comment_count',0),'subscriber_count':data.get('subscriber_count',0),
        'total_views':data.get('total_views',0),'video_count':data.get('video_count',0),
        'published_days_ago':data.get('published_days_ago',0),
        'channel_age_years':data.get('channel_age_years',0),
        # Instagram
        'followers_count':data.get('followers_count',0),'following_count':data.get('following_count',0),
        'posts_count':data.get('posts_count',0),'likes_count':data.get('likes_count',0),
        'comments_count':data.get('comments_count',0),'saves_count':data.get('saves_count',0),
        'shares_count':data.get('shares_count',0),'avg_likes':data.get('avg_likes',0),
        # Facebook
        'page_likes':data.get('page_likes',0),'reactions_count':data.get('reactions_count',0),
        'avg_reactions':data.get('avg_reactions',0),'avg_shares':data.get('avg_shares',0),
        'posts_per_week':data.get('posts_per_week',0),
        # Scores
        'overall_score':scores['overall_score'],'performance_grade':scores['grade'],
        'performance_label':scores['performance_label'],'score_color':scores['color'],
        'engagement_score':scores['engagement_score'],'reach_score':scores['reach_score'],
        'health_score':scores['health_score'],'engagement_rate':scores['engagement_rate'],
        'engagement_strength':scores['engagement_strength'],'reach_effectiveness':scores['reach_effectiveness'],
        # Sentiment
        'sentiment':{'total':sentiment.get('total',0),'positive':sentiment.get('positive',0),
            'negative':sentiment.get('negative',0),'neutral':sentiment.get('neutral',0),
            'spam':sentiment.get('spam',0),'positive_pct':sentiment.get('positive_pct',0),
            'negative_pct':sentiment.get('negative_pct',0),'neutral_pct':sentiment.get('neutral_pct',0),
            'spam_pct':sentiment.get('spam_pct',0),'all_positive':sentiment.get('all_positive',[]),
            'all_negative':sentiment.get('all_negative',[]),'top_positive':sentiment.get('top_positive',[]),
            'top_negative':sentiment.get('top_negative',[])},
        # Fraud
        'fraud':{'score':fraud['fraud_score'],'risk_level':fraud['risk_level'],
            'alerts':fraud.get('alerts',[]),'bot_detected':fraud.get('bot_activity_detected',False),
            'view_spike':fraud.get('view_spike_detected',False),'fake_engagement':fraud.get('fake_engagement_detected',False),
            'spam_count':fraud.get('spam_count',0)},
        'growth_trend':trend,
    }
