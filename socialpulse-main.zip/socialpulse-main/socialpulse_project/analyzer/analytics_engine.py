"""
Analytics Engine — Sentiment Analysis + Fraud Detection + Scoring
Supports: YouTube, Instagram, Facebook
"""
import re
from datetime import datetime
from collections import Counter

POSITIVE_WORDS = {
    'amazing','awesome','excellent','great','love','best','fantastic','wonderful',
    'perfect','brilliant','helpful','incredible','outstanding','superb','beautiful',
    'good','nice','cool','interesting','informative','inspiring','entertaining','fun',
    'useful','thanks','thank','appreciate','recommend','like','enjoy','learned',
    'quality','clear','subscribed','stunning','breathtaking','sharing','uplifting',
}
NEGATIVE_WORDS = {
    'terrible','awful','bad','worst','hate','boring','useless','waste','disappointing',
    'poor','horrible','disgusting','pathetic','stupid','dumb','clickbait','misleading',
    'fake','scam','fraud','dislike','rubbish','garbage','trash','wrong','incorrect',
    'annoying','irritating','slow','overrated','repetitive','outdated',
}
SPAM_PATTERNS = [
    r'(sub.*4.*sub|s4s|sub\s*for\s*sub|follow.*4.*follow|f4f)',
    r'(check\s*out\s*my\s*(channel|page|account|video))',
    r'(follow\s*me|visit\s*my|like\s*my\s*page)',
    r'(www\.|http|\.com|\.net|\.org|\.xyz)\S+',
    r'(buy\s*(views|likes|subscribers|followers))',
    r'(earn\s*money|make\s*money|\$\d+.*day)',
    r'^(first!?|first\s*comment)$',
    r'(click\s*here|limited\s*time)',
    r'(dm\s*me|message\s*me)\s*(for|to)',
    r'(win.*free|free.*iphone|giveaway.*click)',
    r'(share\s*this\s*to\s*\d+)',
]

def analyze_sentiment_text(text):
    if not text:
        return 'neutral', 0.0
    tl = text.lower().strip()
    for p in SPAM_PATTERNS:
        if re.search(p, tl, re.IGNORECASE):
            return 'spam', -0.8
    words = re.findall(r'\b\w+\b', tl)
    pos = sum(1 for w in words if w in POSITIVE_WORDS)
    neg = sum(1 for w in words if w in NEGATIVE_WORDS)
    if any(e in text for e in ['❤️','😍','🔥','👏','😊','💯','✨','🎉','💫','🙏']):
        pos += 1
    if any(e in text for e in ['👎','😤','😡','🤮','💩','😒']):
        neg += 1
    total = pos + neg
    if total == 0:
        return 'neutral', 0.0
    score = (pos - neg) / total
    if score > 0.1:   return 'positive', min(score, 1.0)
    elif score < -0.1: return 'negative', max(score, -1.0)
    return 'neutral', score

def analyze_comments(comments):
    if not comments:
        return _empty()
    results = {'positive':[],'negative':[],'neutral':[],'spam':[],'all':[]}
    scores = []
    author_counts = Counter()
    for c in comments:
        text   = c.get('text', '')
        author = c.get('author', 'Unknown')
        likes  = c.get('likes', 0)
        author_counts[author] += 1
        pre = c.get('sentiment', '')
        if pre in ('positive','negative','spam','neutral'):
            sentiment = pre
            score = 0.7 if pre=='positive' else -0.6 if pre=='negative' else -0.8 if pre=='spam' else 0.0
        else:
            sentiment, score = analyze_sentiment_text(text)
        scores.append(score)
        obj = {'text':text[:250],'author':author,'sentiment':sentiment,'score':round(score,3),'likes':likes}
        results[sentiment].append(obj)
        results['all'].append(obj)
    t = len(comments)
    pos_n=len(results['positive']); neg_n=len(results['negative'])
    neu_n=len(results['neutral']);  spa_n=len(results['spam'])
    return {
        'total':t,'positive':pos_n,'negative':neg_n,'neutral':neu_n,'spam':spa_n,
        'positive_pct':round(pos_n/t*100,1),'negative_pct':round(neg_n/t*100,1),
        'neutral_pct': round(neu_n/t*100,1),'spam_pct':    round(spa_n/t*100,1),
        'avg_score':round(sum(scores)/len(scores),3) if scores else 0,
        'top_positive':results['positive'][:3],'top_negative':results['negative'][:3],
        'spam_examples':results['spam'][:3],
        'all_positive':results['positive'],'all_negative':results['negative'],
        'repeated_authors':{k:v for k,v in author_counts.items() if v>2},
    }

def _empty():
    return {'total':0,'positive':0,'negative':0,'neutral':0,'spam':0,
        'positive_pct':0,'negative_pct':0,'neutral_pct':0,'spam_pct':0,'avg_score':0,
        'top_positive':[],'top_negative':[],'spam_examples':[],'all_positive':[],'all_negative':[],'repeated_authors':{}}

def detect_fraud(data, sentiment):
    alerts=[]; score=0.0
    platform=data.get('platform','youtube'); ctype=data.get('type','video')
    spam_pct=sentiment.get('spam_pct',0)
    if spam_pct>15:
        sev='critical' if spam_pct>40 else 'high' if spam_pct>25 else 'medium'
        alerts.append({'type':'spam_comments','severity':sev,'icon':'🗑️',
            'description':f'{spam_pct:.1f}% of comments flagged as spam ({sentiment["spam"]} comments)',
            'evidence':'Detected promotional links, bot-like phrases, follow-4-follow patterns.'})
        score+=min(spam_pct,30)
    repeated=sentiment.get('repeated_authors',{})
    if len(repeated)>=2:
        alerts.append({'type':'bot_activity','severity':'high','icon':'🤖',
            'description':f'{len(repeated)} accounts posting multiple identical comments',
            'evidence':f'Repeated accounts: {", ".join(list(repeated.keys())[:4])}'})
        score+=18
    if platform=='youtube':
        v=data.get('view_count',0); l=data.get('like_count',0); c=data.get('comment_count',0)
        if ctype=='video' and v>0:
            lr=l/v
            if lr>0.15:
                alerts.append({'type':'like_spike','severity':'high','icon':'👍',
                    'description':f'Abnormal like-to-view ratio: {lr:.1%}',
                    'evidence':f'{l:,} likes on {v:,} views. Normal range: 2-8%.'})
                score+=25
            if v>500000 and c<50:
                alerts.append({'type':'view_spike','severity':'medium','icon':'📈',
                    'description':'Disproportionate views vs. comments — possible view inflation',
                    'evidence':f'Only {c} comments for {v:,} views.'})
                score+=15
        if ctype=='channel':
            subs=data.get('subscriber_count',0)
            if subs>0:
                vps=data.get('total_views',0)/subs
                if vps<2 and subs>10000:
                    alerts.append({'type':'fake_engagement','severity':'high','icon':'🎭',
                        'description':f'Very low view-to-subscriber ratio ({vps:.1f}x)',
                        'evidence':'May indicate purchased subscribers.'})
                    score+=22
    elif platform=='instagram':
        if ctype=='profile':
            f=data.get('followers_count',0); al=data.get('avg_likes',0); fo=data.get('following_count',0)
            if f>0 and al>0:
                er=al/f
                if er<0.005 and f>100000:
                    alerts.append({'type':'fake_followers','severity':'high','icon':'👥',
                        'description':f'Abnormally low engagement rate: {er:.2%}',
                        'evidence':'Authentic profiles of this size average 1-5% engagement.'})
                    score+=28
            if f>500000 and fo>10000:
                alerts.append({'type':'bot_activity','severity':'medium','icon':'🤖',
                    'description':'Unusual follower-to-following ratio',
                    'evidence':f'Following {fo:,} accounts - possible follow/unfollow bot.'})
                score+=14
    elif platform=='facebook':
        if ctype=='page':
            ar=data.get('avg_reactions',0); as_=data.get('avg_shares',0); ppw=data.get('posts_per_week',0)
            if ar>0 and as_/max(ar,1)>0.5:
                alerts.append({'type':'share_farming','severity':'medium','icon':'🔄',
                    'description':'Abnormal share-to-reaction ratio — possible share farming',
                    'evidence':f'{as_:,} avg shares vs {ar:,} avg reactions.'})
                score+=18
            if ppw>50:
                alerts.append({'type':'post_flooding','severity':'medium','icon':'⚡',
                    'description':f'Excessive posting frequency: {ppw} posts/week',
                    'evidence':'Pages posting 50+ times/week often use automated bots.'})
                score+=12
    score=min(round(score,1),100)
    risk='Low' if score<15 else 'Medium' if score<40 else 'High' if score<65 else 'Critical'
    return {'fraud_score':score,'risk_level':risk,'alerts':alerts,
        'bot_activity_detected':any(a['type']=='bot_activity' for a in alerts),
        'view_spike_detected':any(a['type']=='view_spike' for a in alerts),
        'fake_engagement_detected':any(a['type'] in ('fake_engagement','fake_followers') for a in alerts),
        'spam_count':sentiment.get('spam',0)}

def calculate_scores(data, sentiment, fraud):
    platform=data.get('platform','youtube'); ctype=data.get('type','video')
    if platform=='youtube':      eng,reach,er=_score_yt(data,ctype)
    elif platform=='instagram':  eng,reach,er=_score_ig(data,ctype)
    else:                        eng,reach,er=_score_fb(data,ctype)
    health=eng*0.4+sentiment.get('positive_pct',50)*0.35+reach*0.25
    raw=eng*0.35+sentiment.get('positive_pct',50)*0.25+reach*0.25+health*0.15
    overall=max(0,raw-fraud['fraud_score']*0.28)
    score=round(overall,1)
    grade='A' if score>=85 else 'B' if score>=70 else 'C' if score>=55 else 'D' if score>=40 else 'F'
    label='Excellent' if score>=85 else 'Good' if score>=70 else 'Average' if score>=55 else 'Below Average' if score>=40 else 'Poor'
    color='#00d4a0' if score>=85 else '#4ecdc4' if score>=70 else '#ffe66d' if score>=55 else '#ff9f43' if score>=40 else '#ff6b6b'
    return {'overall_score':score,'grade':grade,'performance_label':label,'color':color,
        'engagement_score':round(eng,1),'reach_score':round(reach,1),'health_score':round(health,1),
        'engagement_rate':round(er,3),
        'engagement_strength':'Strong' if eng>=80 else 'Moderate' if eng>=60 else 'Weak' if eng>=40 else 'Very Weak',
        'reach_effectiveness':'Excellent' if reach>=80 else 'Good' if reach>=60 else 'Moderate' if reach>=40 else 'Limited'}

def _score_yt(data,ctype):
    if ctype=='video':
        v,l,c=data.get('view_count',0),data.get('like_count',0),data.get('comment_count',0)
        er=(l+c)/v*100 if v>0 else 0
        eng=95 if er>=5 else 80 if er>=3 else 62 if er>=1 else 42 if er>=0.5 else 22
        reach=95 if v>=1e7 else 82 if v>=1e6 else 65 if v>=1e5 else 45 if v>=1e4 else 25
        return eng,reach,round(er,3)
    else:
        s=data.get('subscriber_count',0); er=data.get('total_views',0)/s if s>0 else 0
        eng=95 if s>=1e7 else 82 if s>=1e6 else 65 if s>=1e5 else 45 if s>=1e4 else 25
        reach=90 if er>=100 else 75 if er>=50 else 55 if er>=10 else 38 if er>=3 else 20
        return eng,reach,round(er,1)

def _score_ig(data,ctype):
    if ctype=='post':
        l=data.get('likes_count',0); c=data.get('comments_count',0); sv=data.get('saves_count',0)
        er=(c+sv)/l*100 if l>0 else 0
        eng=95 if er>=10 else 80 if er>=5 else 65 if er>=2 else 45 if er>=0.5 else 25
        reach=95 if l>=1e6 else 80 if l>=1e5 else 65 if l>=1e4 else 45 if l>=1e3 else 25
        return eng,reach,round(er,2)
    else:
        f=data.get('followers_count',0); al=data.get('avg_likes',0)
        er=al/f*100 if f>0 else 0
        eng=95 if er>=5 else 78 if er>=2 else 60 if er>=1 else 40 if er>=0.3 else 22
        reach=95 if f>=1e7 else 82 if f>=1e6 else 65 if f>=1e5 else 45 if f>=1e4 else 25
        return eng,reach,round(er,2)

def _score_fb(data,ctype):
    if ctype=='post':
        r=data.get('reactions_count',0); c=data.get('comments_count',0); s=data.get('shares_count',0)
        er=(c+s)/r*100 if r>0 else 0
        eng=90 if er>=15 else 75 if er>=8 else 60 if er>=4 else 42 if er>=2 else 25
        reach=90 if r>=1e5 else 75 if r>=1e4 else 58 if r>=1e3 else 40 if r>=100 else 22
        return eng,reach,round(er,2)
    else:
        f=data.get('followers_count',0); ar=data.get('avg_reactions',0)
        er=ar/f*100 if f>0 else 0
        eng=90 if er>=1 else 75 if er>=0.5 else 58 if er>=0.2 else 40 if er>=0.05 else 22
        reach=95 if f>=1e7 else 82 if f>=1e6 else 65 if f>=1e5 else 45 if f>=1e4 else 25
        return eng,reach,round(er,3)

def generate_growth_trend(data):
    import random
    rng=random.Random(sum(ord(c) for c in str(data.get('id','x'))))
    base=(data.get('subscriber_count') or data.get('followers_count') or
          data.get('view_count') or data.get('reactions_count') or 100000)*0.55
    months=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    m=datetime.now().month
    labels=[months[(m-6+i)%12] for i in range(6)]
    v=base; vals=[]
    for _ in labels:
        v*=(1+rng.uniform(0.02,0.14)); vals.append(int(v))
    return {'labels':labels,'values':vals}
