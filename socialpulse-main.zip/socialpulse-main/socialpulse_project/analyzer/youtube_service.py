
import re, json, random
from django.conf import settings

def parse_youtube_url(url):
    url=url.strip()
    for p in [r"(?:youtube\.com/watch\?v=|youtu\.be/|youtube\.com/embed/)([a-zA-Z0-9_-]{11})",r"youtube\.com/shorts/([a-zA-Z0-9_-]{11})"]:
        m=re.search(p,url)
        if m: return {"type":"video","id":m.group(1)}
    for p in [r"youtube\.com/@([a-zA-Z0-9_.-]+)",r"youtube\.com/channel/([a-zA-Z0-9_-]+)",r"youtube\.com/user/([a-zA-Z0-9_-]+)",r"youtube\.com/c/([a-zA-Z0-9_-]+)"]:
        m=re.search(p,url)
        if m: return {"type":"channel","id":m.group(1)}
    return None

def fetch_youtube_data(url):
    parsed=parse_youtube_url(url)
    if not parsed: raise ValueError("Invalid YouTube URL")
    try:
        api_key=settings.YOUTUBE_API_KEY
        if api_key and api_key!="YOUR_YOUTUBE_API_KEY_HERE":
            return _fetch_real(parsed,api_key)
    except: pass
    return _mock(parsed,url)

def _fetch_real(parsed,api_key):
    import urllib.request,urllib.parse
    base="https://www.googleapis.com/youtube/v3"
    data={"type":parsed["type"],"id":parsed["id"],"comments":[],"source":"youtube_api"}
    if parsed["type"]=="video":
        params=urllib.parse.urlencode({"part":"snippet,statistics","id":parsed["id"],"key":api_key})
        r=json.loads(urllib.request.urlopen(f"{base}/videos?{params}",timeout=10).read().decode())
        if not r.get("items"): raise ValueError("Video not found")
        item=r["items"][0]; s=item["snippet"]; st=item.get("statistics",{})
        data.update({"title":s.get("title",""),"channel_name":s.get("channelTitle",""),"channel_id":s.get("channelId",""),"view_count":int(st.get("viewCount",0)),"like_count":int(st.get("likeCount",0)),"comment_count":int(st.get("commentCount",0)),"thumbnail":s.get("thumbnails",{}).get("high",{}).get("url","")})
        try:
            params2=urllib.parse.urlencode({"part":"snippet","videoId":parsed["id"],"maxResults":100,"key":api_key})
            cr=json.loads(urllib.request.urlopen(f"{base}/commentThreads?{params2}",timeout=10).read().decode())
            data["comments"]=[{"text":c["snippet"]["topLevelComment"]["snippet"]["textDisplay"],"author":c["snippet"]["topLevelComment"]["snippet"]["authorDisplayName"],"likes":c["snippet"]["topLevelComment"]["snippet"]["likeCount"]} for c in cr.get("items",[])]
        except: pass
    else:
        channel_id=parsed["id"]
        if not channel_id.startswith("UC"):
            try:
                params=urllib.parse.urlencode({"part":"id","forHandle":f"@{channel_id}","key":api_key})
                cr=json.loads(urllib.request.urlopen(f"{base}/channels?{params}",timeout=10).read().decode())
                if cr.get("items"): channel_id=cr["items"][0]["id"]
            except: pass
        params=urllib.parse.urlencode({"part":"snippet,statistics","id":channel_id,"key":api_key})
        r=json.loads(urllib.request.urlopen(f"{base}/channels?{params}",timeout=10).read().decode())
        if not r.get("items"): raise ValueError("Channel not found")
        item=r["items"][0]; s=item["snippet"]; st=item.get("statistics",{})
        data.update({"channel_name":s.get("title",""),"channel_id":item["id"],"subscriber_count":int(st.get("subscriberCount",0)),"total_views":int(st.get("viewCount",0)),"video_count":int(st.get("videoCount",0)),"country":s.get("country","")})
    return data

PRESET_VIDEOS={"dQw4w9WgXcQ":{"title":"Never Gonna Give You Up","channel":"Rick Astley","views":1500000000,"likes":15000000,"comments":2800000},"jNQXAC9IVRw":{"title":"Me at the zoo","channel":"jawed","views":32000000,"likes":220000,"comments":110000}}
PRESET_CHANNELS={"MrBeast":{"name":"MrBeast","subs":240000000,"views":41000000000,"vids":800,"country":"US","age":12},"PewDiePie":{"name":"PewDiePie","subs":111000000,"views":28000000000,"vids":4500,"country":"JP","age":14},"UCX6OQ3DkcsbYNE6H8uQQuVA":{"name":"MrBeast","subs":240000000,"views":41000000000,"vids":800,"country":"US","age":12}}
POS=[{"text":"This video is absolutely amazing! Best content on YouTube!","author":"Sarah_Johnson"},{"text":"Great explanation, really helped me understand this.","author":"TechLearner99"},{"text":"I watched this 3 times already. Such quality! ","author":"Mike_Peters_42"},{"text":"This changed my perspective. Thank you! ","author":"Emma_Wilson"},{"text":"Finally someone explaining this properly! Subscribed!","author":"David_Brown_UK"},{"text":"Absolutely brilliant. This is why I love this channel.","author":"Alex_Chen_Dev"}]
NEG=[{"text":"Clickbait title, video doesn't deliver what it promises.","author":"DisappointedViewer"},{"text":"Audio quality is terrible and hard to follow.","author":"QualityCritic_X"},{"text":"Too long and boring, get to the point.","author":"BusyUser123"},{"text":"Completely misleading. Won't watch again.","author":"HonestReview99"}]
SPAM=[{"text":"Buy 10000 subscribers cheap!! visit 999subs.com!!","author":"PromoBot_44"},{"text":"Check out my channel for BETTER content!!","author":"SubFarm_99"},{"text":"FIRST!!! ","author":"FirstComment_Bot"},{"text":"Sub 4 sub? I will sub back instantly!","author":"SubSwap_2024"},{"text":"www.earn-money-fast.xyz Make $500/day!!","author":"SpamLink_Bot"}]

def _mock(parsed,url,error=None):
    rng=random.Random(sum(ord(c) for c in parsed["id"]))
    if parsed["type"]=="video":
        p=PRESET_VIDEOS.get(parsed["id"])
        views=p["views"] if p else rng.randint(50000,15000000)
        likes=p["likes"] if p else int(views*rng.uniform(0.02,0.08))
        comments=p["comments"] if p else int(views*rng.uniform(0.001,0.01))
        posC=rng.randint(3,6); negC=rng.randint(1,4); spamC=rng.randint(1,5)
        pool=([{"text":c["text"],"author":c["author"],"sentiment":"positive","likes":rng.randint(5,500)} for c in POS[:posC]]+[{"text":c["text"],"author":c["author"],"sentiment":"negative","likes":rng.randint(0,50)} for c in NEG[:negC]]+[{"text":c["text"],"author":c["author"],"sentiment":"spam","likes":0} for c in SPAM[:spamC]])
        return {"platform":"youtube","type":"video","id":parsed["id"],"title":p["title"] if p else f"YouTube Video ({parsed['id'][:8]}...)","channel_name":p["channel"] if p else "Demo Channel","channel_id":"demo","view_count":views,"like_count":likes,"comment_count":comments,"published_days_ago":rng.randint(30,2000),"comments":pool,"source":"demo","demo_note":error or ""}
    else:
        k=next((k for k in PRESET_CHANNELS if parsed["id"].lower() in k.lower() or k.lower() in parsed["id"].lower()),None)
        p=PRESET_CHANNELS.get(k)
        subs=p["subs"] if p else rng.randint(10000,5000000)
        views=p["views"] if p else subs*rng.randint(50,400)
        vids=p["vids"] if p else rng.randint(50,1000)
        posC=rng.randint(3,6); negC=rng.randint(1,3); spamC=rng.randint(1,4)
        pool=([{"text":c["text"],"author":c["author"],"sentiment":"positive","likes":rng.randint(5,500)} for c in POS[:posC]]+[{"text":c["text"],"author":c["author"],"sentiment":"negative","likes":rng.randint(0,50)} for c in NEG[:negC]]+[{"text":c["text"],"author":c["author"],"sentiment":"spam","likes":0} for c in SPAM[:spamC]])
        return {"platform":"youtube","type":"channel","id":parsed["id"],"channel_name":p["name"] if p else f"@{parsed['id'][:15]}","channel_id":parsed["id"],"subscriber_count":subs,"total_views":views,"video_count":vids,"country":p["country"] if p else "US","channel_age_years":p["age"] if p else rng.randint(1,10),"comments":pool,"source":"demo","demo_note":error or ""}
