
import re, json, random, requests
from django.conf import settings

def parse_instagram_url(url):
    url=url.strip()
    for p in [r"instagram\.com/p/([a-zA-Z0-9_-]+)",r"instagram\.com/reel/([a-zA-Z0-9_-]+)"]:
        m=re.search(p,url)
        if m: return {"type":"post","id":m.group(1)}
    m=re.search(r"instagram\.com/([a-zA-Z0-9_.]+)/?$",url)
    if m and m.group(1) not in ["p","reel","explore","accounts"]: return {"type":"profile","id":m.group(1)}
    return None

def fetch_instagram_data(url):
    parsed=parse_instagram_url(url)
    if not parsed: raise ValueError("Invalid Instagram URL")
    try:
        return _fetch_from_rapidapi(parsed, url)
    except Exception as e:
        return _mock(parsed, url, str(e))

def _fetch_from_rapidapi(parsed, url):
    """Fetch real Instagram data from RAPIDAPI"""
    headers = {
        "x-rapidapi-key": settings.RAPIDAPI_KEY,
        "x-rapidapi-host": settings.RAPIDAPI_HOST
    }
    
    if parsed["type"] == "profile":
        api_url = f"https://{settings.RAPIDAPI_HOST}/user/info"
        params = {"user_name": parsed["id"]}
        response = requests.get(api_url, headers=headers, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        # Map RAPIDAPI response to expected format
        user = data.get('user', data.get('data', {}))
        return {
            "platform": "instagram",
            "type": "profile",
            "id": parsed["id"],
            "channel_name": user.get('full_name') or user.get('username') or parsed["id"],
            "handle": f"@{user.get('username', parsed['id'])}",
            "followers_count": user.get('followers_count', user.get('follower_count', 0)),
            "following_count": user.get('following_count', user.get('follow_count', 0)),
            "posts_count": user.get('media_count', user.get('posts_count', 0)),
            "avg_likes": user.get('avg_likes', 0),
            "avg_comments": user.get('avg_comments', 0),
            "verified": user.get('is_verified', False),
            "country": user.get('country', ""),
            "niche": user.get('category_name', "Lifestyle"),
            "bio": user.get('biography', ''),
            "profile_pic": user.get('profile_pic_url', ''),
            "comments": [],
            "source": "rapidapi",
            "demo_note": ""
        }
    else:
        api_url = f"https://{settings.RAPIDAPI_HOST}/post/info"
        params = {"post_code": parsed["id"]}
        response = requests.get(api_url, headers=headers, params=params, timeout=10)
        response.raise_for_status()
        data = response.json()
        # Map RAPIDAPI response to expected format
        post = data.get('post', data.get('data', {}))
        return {
            "platform": "instagram",
            "type": "post",
            "id": parsed["id"],
            "channel_name": post.get('owner', {}).get('username', 'instagram_user'),
            "caption": post.get('caption', ''),
            "likes_count": post.get('like_count', 0),
            "comments_count": post.get('comments_count', post.get('comment_count', 0)),
            "saves_count": post.get('save_count', 0),
            "shares_count": post.get('share_count', 0),
            "published_days_ago": post.get('days_ago', 0),
            "image_url": post.get('display_url', post.get('image_url', '')),
            "comments": [],
            "source": "rapidapi",
            "demo_note": ""
        }

PROFILES={"cristiano":{"name":"Cristiano Ronaldo","followers":635000000,"following":567,"posts":3700,"verified":True,"country":"PT","niche":"Sports","avg_likes":8200000,"avg_comments":52000},"natgeo":{"name":"National Geographic","followers":280000000,"following":200,"posts":28000,"verified":True,"country":"US","niche":"Nature & Science","avg_likes":120000,"avg_comments":800},"nasa":{"name":"NASA","followers":97000000,"following":75,"posts":4200,"verified":True,"country":"US","niche":"Science","avg_likes":210000,"avg_comments":1200},"leomessi":{"name":"Leo Messi","followers":500000000,"following":300,"posts":1100,"verified":True,"country":"AR","niche":"Sports","avg_likes":6000000,"avg_comments":40000}}
POSTS={"ABC123xyz":{"caption":"Exploring the beauty of our world ","author":"natgeo","likes":420000,"comments":3200,"shares":18000,"saves":95000,"days_ago":3}}
POS=[{"text":"Stunning shot! Colors are breathtaking ","author":"photoLover_88"},{"text":"This content always gives me life. Never stop posting!","author":"InstaDaily_x"},{"text":"The composition is just perfect. So inspiring ","author":"creative_soul_42"},{"text":"I wait for your posts every day. Never disappoints!","author":"loyal_fan_2024"},{"text":"This is pure art. Thank you for sharing ","author":"art_appreciation_"},{"text":"Absolutely incredible! Deserves way more likes ","author":"SocialMediaFan99"}]
NEG=[{"text":"Way too many filters. Doesn't look natural at all.","author":"RealTalk_2024"},{"text":"Quality has dropped a lot recently. Disappointing.","author":"OldFollower_98"},{"text":"Doesn't match your usual standard. Come on.","author":"CriticalEye_77"},{"text":"Overrated content honestly. Nothing special.","author":"HonestUser_IG"}]
SPAM=[{"text":"Follow me back! I followed you!","author":"F4F_Bot_2024"},{"text":"CHECK MY PAGE for amazing content!!","author":"PromoAccount_99"},{"text":"FIRST COMMENT!","author":"FirstBot_IG"},{"text":"DM me to collab! Fast grow guaranteed!","author":"FakeGrowth_Bot"}]

def _mock(parsed,url,error=None):
    rng=random.Random(sum(ord(c) for c in parsed["id"]))
    if parsed["type"]=="post":
        p=POSTS.get(parsed["id"])
        likes=p["likes"] if p else rng.randint(5000,500000)
        comments=p["comments"] if p else int(likes*rng.uniform(0.005,0.03))
        saves=p["saves"] if p else int(likes*rng.uniform(0.1,0.3))
        shares=p["shares"] if p else int(likes*rng.uniform(0.05,0.2))
        posC=rng.randint(3,5); negC=rng.randint(1,3); spamC=rng.randint(1,4)
        pool=([{"text":c["text"],"author":c["author"],"sentiment":"positive","likes":rng.randint(5,300)} for c in POS[:posC]]+[{"text":c["text"],"author":c["author"],"sentiment":"negative","likes":rng.randint(0,30)} for c in NEG[:negC]]+[{"text":c["text"],"author":c["author"],"sentiment":"spam","likes":0} for c in SPAM[:spamC]])
        return {"platform":"instagram","type":"post","id":parsed["id"],"channel_name":p["author"] if p else "instagram_user","caption":p["caption"] if p else "Instagram Post","likes_count":likes,"comments_count":comments,"saves_count":saves,"shares_count":shares,"published_days_ago":p["days_ago"] if p else rng.randint(1,90),"comments":pool,"source":"demo","demo_note":error or ""}
    else:
        k=next((k for k in PROFILES if k.lower()==parsed["id"].lower()),None)
        p=PROFILES.get(k)
        followers=p["followers"] if p else rng.randint(5000,2000000)
        posC=rng.randint(3,5); negC=rng.randint(1,3); spamC=rng.randint(1,4)
        pool=([{"text":c["text"],"author":c["author"],"sentiment":"positive","likes":rng.randint(5,300)} for c in POS[:posC]]+[{"text":c["text"],"author":c["author"],"sentiment":"negative","likes":rng.randint(0,30)} for c in NEG[:negC]]+[{"text":c["text"],"author":c["author"],"sentiment":"spam","likes":0} for c in SPAM[:spamC]])
        return {"platform":"instagram","type":"profile","id":parsed["id"],"channel_name":p["name"] if p else f"@{parsed['id']}","handle":f"@{parsed['id']}","followers_count":followers,"following_count":p["following"] if p else rng.randint(100,5000),"posts_count":p["posts"] if p else rng.randint(50,2000),"avg_likes":p["avg_likes"] if p else int(followers*rng.uniform(0.005,0.05)),"avg_comments":p["avg_comments"] if p else int(followers*0.003),"verified":p["verified"] if p else False,"country":p["country"] if p else "US","niche":p["niche"] if p else "Lifestyle","comments":pool,"source":"demo","demo_note":error or ""}
