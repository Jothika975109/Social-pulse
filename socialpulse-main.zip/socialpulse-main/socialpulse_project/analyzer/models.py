from django.db import models
from django.utils import timezone

PLATFORM_CHOICES = [('youtube','YouTube'),('instagram','Instagram'),('facebook','Facebook')]

class SocialProfile(models.Model):
    platform=models.CharField(max_length=20,choices=PLATFORM_CHOICES)
    profile_id=models.CharField(max_length=200)
    profile_name=models.CharField(max_length=255)
    handle=models.CharField(max_length=255,blank=True)
    profile_url=models.URLField(max_length=500)
    followers_count=models.BigIntegerField(default=0)
    following_count=models.BigIntegerField(default=0)
    total_posts=models.IntegerField(default=0)
    total_views=models.BigIntegerField(default=0)
    country=models.CharField(max_length=100,blank=True)
    verified=models.BooleanField(default=False)
    category=models.CharField(max_length=100,blank=True)
    created_at=models.DateTimeField(default=timezone.now)
    last_analyzed=models.DateTimeField(auto_now=True)
    class Meta:
        db_table='social_profiles'
        unique_together=('platform','profile_id')
    def __str__(self):
        return f"[{self.platform}] {self.profile_name}"

class SocialPost(models.Model):
    platform=models.CharField(max_length=20,choices=PLATFORM_CHOICES)
    post_id=models.CharField(max_length=200)
    profile=models.ForeignKey(SocialProfile,on_delete=models.CASCADE,null=True,blank=True)
    title=models.CharField(max_length=500,blank=True)
    post_url=models.URLField(max_length=500)
    view_count=models.BigIntegerField(default=0)
    like_count=models.BigIntegerField(default=0)
    comment_count=models.BigIntegerField(default=0)
    share_count=models.BigIntegerField(default=0)
    save_count=models.BigIntegerField(default=0)
    reaction_count=models.BigIntegerField(default=0)
    created_at=models.DateTimeField(default=timezone.now)
    last_analyzed=models.DateTimeField(auto_now=True)
    class Meta:
        db_table='social_posts'
        unique_together=('platform','post_id')
    def __str__(self):
        return f"[{self.platform}] {self.title or self.post_id}"

class AnalyticsReport(models.Model):
    GRADES=[('excellent','Excellent'),('good','Good'),('average','Average'),('poor','Poor'),('critical','Critical')]
    CTYPES=[('channel','YouTube Channel'),('video','YouTube Video'),('profile','Instagram Profile'),('post','Instagram Post'),('page','Facebook Page'),('fb_post','Facebook Post')]
    platform=models.CharField(max_length=20,choices=PLATFORM_CHOICES,default='youtube')
    content_type=models.CharField(max_length=20,choices=CTYPES)
    profile=models.ForeignKey(SocialProfile,on_delete=models.SET_NULL,null=True,blank=True)
    post=models.ForeignKey(SocialPost,on_delete=models.SET_NULL,null=True,blank=True)
    analyzed_url=models.URLField(max_length=500,blank=True)
    overall_score=models.FloatField(default=0.0)
    performance_grade=models.CharField(max_length=20,choices=GRADES)
    engagement_score=models.FloatField(default=0.0)
    reach_score=models.FloatField(default=0.0)
    health_score=models.FloatField(default=0.0)
    fraud_risk_score=models.FloatField(default=0.0)
    engagement_rate=models.FloatField(default=0.0)
    positive_sentiment=models.FloatField(default=0.0)
    negative_sentiment=models.FloatField(default=0.0)
    neutral_sentiment=models.FloatField(default=0.0)
    spam_detected=models.IntegerField(default=0)
    bot_detected=models.BooleanField(default=False)
    fake_engagement=models.BooleanField(default=False)
    view_spike=models.BooleanField(default=False)
    mongo_report_id=models.CharField(max_length=100,blank=True)
    created_at=models.DateTimeField(default=timezone.now)
    class Meta:
        db_table='analytics_reports'
        ordering=['-created_at']
    def __str__(self):
        return f"[{self.platform}] Report #{self.id} — {self.overall_score}"

class FraudAlert(models.Model):
    SEVS=[('low','Low'),('medium','Medium'),('high','High'),('critical','Critical')]
    TYPES=[('spam_comments','Spam Comments'),('bot_activity','Bot Activity'),('view_spike','View Spike'),('like_spike','Like Spike'),('fake_followers','Fake Followers'),('fake_engagement','Fake Engagement'),('share_farming','Share Farming'),('post_flooding','Post Flooding'),('comment_farming','Comment Farming')]
    report=models.ForeignKey(AnalyticsReport,on_delete=models.CASCADE,related_name='alerts')
    alert_type=models.CharField(max_length=50,choices=TYPES)
    severity=models.CharField(max_length=20,choices=SEVS)
    description=models.TextField()
    evidence=models.TextField(blank=True)
    created_at=models.DateTimeField(default=timezone.now)
    class Meta:
        db_table='fraud_alerts'
    def __str__(self):
        return f"{self.alert_type} — {self.severity}"
