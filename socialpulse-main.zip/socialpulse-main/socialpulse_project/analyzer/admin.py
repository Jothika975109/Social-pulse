from django.contrib import admin
from .models import SocialProfile, SocialPost, AnalyticsReport, FraudAlert

@admin.register(SocialProfile)
class SocialProfileAdmin(admin.ModelAdmin):
    list_display = ['platform','profile_name','handle','followers_count','verified','last_analyzed']
    list_filter = ['platform','verified']
    search_fields = ['profile_name','handle']

@admin.register(SocialPost)
class SocialPostAdmin(admin.ModelAdmin):
    list_display = ['platform','title','like_count','view_count','comment_count']
    list_filter = ['platform']

@admin.register(AnalyticsReport)
class AnalyticsReportAdmin(admin.ModelAdmin):
    list_display = ['id','platform','content_type','overall_score','performance_grade','fraud_risk_score','created_at']
    list_filter = ['platform','content_type','performance_grade']
    ordering = ['-created_at']

@admin.register(FraudAlert)
class FraudAlertAdmin(admin.ModelAdmin):
    list_display = ['report','alert_type','severity','created_at']
    list_filter = ['alert_type','severity']
