# SocialPulse — Multi-Platform Analytics & Fraud Detection

Full-stack Django platform for analyzing YouTube, Instagram, and Facebook content with fraud detection, sentiment analysis, and performance scoring.

## 🚀 Quick Start

```bash
pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py runserver
```

Open: http://127.0.0.1:8000

## 📋 Platform Support

| Platform  | Content Types        | API Key Required              |
|-----------|---------------------|-------------------------------|
| YouTube   | Videos & Channels   | YouTube Data API v3           |
| Instagram | Posts & Profiles    | RapidAPI           |
| Facebook  | Pages & Posts       | Facebook Graph API            |

## 🔑 API Keys (Optional — works in demo mode without them)

Edit `socialpulse/settings.py`:

```python
YOUTUBE_API_KEY      = 'AIzaSyBIyLZ46MjdsF0zy8HG1vNH8IapN2cu3Qcey'
INSTAGRAM_ACCESS_TOKEN = 'cc2e64cdf1mshd608fb14e7a3007p1b7c1ejsnd09df3718'
FACEBOOK_ACCESS_TOKEN  = 'EAAXT57fwGU8BRPZAbArqCUiZCNEPaNK5VPNFeJZCEZAEvZBfQHwyHBCZAbkLTRCiua7ZA9u8QcxL0gsMc0a2F1mvMrI7qMjHnkRmKYaJDpt0emb0uZBpCf8CpKMlzMKsl9CwQcZACNHA4nKOwvu4pRoCA3NT4hDFuF3kSSmjcjnrftJxcGbZAGFgQrfZAG6ZBgNCEpuEDVXUXkG23FKg7bqx3qqNELAZA5BpCqJdIx3wc7DGQtwNObOTNxxGX9YPgiO0LCtE2t2wWTd0fnB7EFgMZBnI0l'

- YouTube API: https://console.cloud.google.com → Enable YouTube Data API v3
- Instagram/Facebook: https://developers.facebook.com → Create App → Graph API

## 📦 Files

```
socialpulse_project/
├── manage.py
├── requirements.txt
├── socialpulse_demo.html        ← Standalone browser demo (no server needed)
├── socialpulse/
│   ├── settings.py              ← API keys here
│   ├── urls.py
│   └── wsgi.py
└── analyzer/
    ├── models.py                ← SQL: SocialProfile, SocialPost, AnalyticsReport, FraudAlert
    ├── views.py                 ← Routes by platform
    ├── youtube_service.py       ← YouTube API + mock data
    ├── instagram_service.py     ← Instagram API + mock data
    ├── facebook_service.py      ← Facebook API + mock data
    ├── analytics_engine.py      ← Sentiment analysis + fraud detection + scoring
    ├── mongodb_service.py       ← MongoDB for comments & fraud logs
    ├── admin.py
    ├── urls.py
    └── templates/analyzer/
        ├── index.html           ← Main 3-platform dashboard
        ├── history.html         ← All past analyses
        └── report.html          ← Individual report view
```

## 🌐 URLs

| URL                  | Description            |
|----------------------|------------------------|
| /                    | Main dashboard         |
| /analyze/            | POST — analyze a URL   |
| /history/            | All past reports       |
| /report/<id>/        | Single report view     |
| /admin/              | Django admin panel     |

## ⚡ Demo Mode

Works without any API key — uses realistic pre-configured mock data for known accounts (MrBeast, Cristiano Ronaldo, NASA, FC Barcelona, etc.)

Also included: `socialpulse_demo.html` — open directly in any browser, no server needed.


Final CMD :
    cd "c:\Users\hi\Downloads\socialpulse updated\socialpulse_project"
    python manage.py runserver