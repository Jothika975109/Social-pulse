import os
from pathlib import Path
BASE_DIR = Path(__file__).resolve().parent.parent
SECRET_KEY = 'socialpulse-secret-key-change-in-production-2024'
DEBUG = True
ALLOWED_HOSTS = ['*']
INSTALLED_APPS = ['django.contrib.admin','django.contrib.auth','django.contrib.contenttypes','django.contrib.sessions','django.contrib.messages','django.contrib.staticfiles','analyzer']
MIDDLEWARE = ['django.middleware.security.SecurityMiddleware','django.contrib.sessions.middleware.SessionMiddleware','django.middleware.common.CommonMiddleware','django.middleware.csrf.CsrfViewMiddleware','django.contrib.auth.middleware.AuthenticationMiddleware','django.contrib.messages.middleware.MessageMiddleware','django.middleware.clickjacking.XFrameOptionsMiddleware']
ROOT_URLCONF = 'socialpulse.urls'
TEMPLATES = [{'BACKEND':'django.template.backends.django.DjangoTemplates','DIRS':[BASE_DIR/'templates'],'APP_DIRS':True,'OPTIONS':{'context_processors':['django.template.context_processors.debug','django.template.context_processors.request','django.contrib.auth.context_processors.auth','django.contrib.messages.context_processors.messages']}}]
WSGI_APPLICATION = 'socialpulse.wsgi.application'
DATABASES = {'default':{'ENGINE':'django.db.backends.sqlite3','NAME':BASE_DIR/'db.sqlite3'}}
MONGODB_SETTINGS = {'HOST':'localhost','PORT':27017,'DB':'socialpulse'}
YOUTUBE_API_KEY = os.environ.get('YOUTUBE_API_KEY','AIzaSyBIyLZ46MjdsF0zy8HG1vNH8IapN2cu3Qc')
RAPIDAPI_KEY = os.environ.get('RAPIDAPI_KEY','cc2e64cdf1mshd608fb14e7a3007p1b7c1ejsnd09df3718068')
RAPIDAPI_HOST = os.environ.get('RAPIDAPI_HOST','instagram-scraper-stable-api.p.rapidapi.com')
INSTAGRAM_USER_ID = os.environ.get('INSTAGRAM_USER_ID','1943873059592910')
FACEBOOK_ACCESS_TOKEN = os.environ.get('FACEBOOK_ACCESS_TOKEN','EAAXT57fwGU8BRPZAbArqCUiZCNEPaNK5VPNFeJZCEZAEvZBfQHwyHBCZAbkLTRCiua7ZA9u8QcxL0gsMc0a2F1mvMrI7qMjHnkRmKYaJDpt0emb0uZBpCf8CpKMlzMKsl9CwQcZACNHA4nKOwvu4pRoCA3NT4hDFuF3kSSmjcjnrftJxcGbZAGFgQrfZAG6ZBgNCEpuEDVXUXkG23FKg7bqx3qqNELAZA5BpCqJdIx3wc7DGQtwNObOTNxxGX9YPgiO0LCtE2t2wWTd0fnB7EFgMZBnI0l')
LANGUAGE_CODE='en-us'; TIME_ZONE='UTC'; USE_I18N=True; USE_TZ=True
STATIC_URL='static/'; STATIC_ROOT=BASE_DIR/'staticfiles'
DEFAULT_AUTO_FIELD='django.db.models.BigAutoField'
